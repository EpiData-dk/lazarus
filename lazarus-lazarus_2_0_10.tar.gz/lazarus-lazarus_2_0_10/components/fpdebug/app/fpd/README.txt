 ---------------------------------------------------------------------------
 fpd  -  FP standalone debugger
 ---------------------------------------------------------------------------

 fpd is a concept Free Pascal Debugger. It is mainly used to test
 the debugger classes, but it may grow someday to a fully functional
 debugger written in pascal. I hope you enjoy it.

 Marc Weustink


