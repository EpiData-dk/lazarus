Some parts of this package were ported from (or based on) DUBY:

http://sourceforge.net/projects/duby/

For details the svn log

Many thanks to Dmitry Boyarintsev for his work on Duby
