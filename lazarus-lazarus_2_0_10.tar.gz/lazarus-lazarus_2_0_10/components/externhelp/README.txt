ExternHelp.lpk
==============

This designtime package allows one to setup online help for bindings. For example,
when the source editor cursor is on an identifier in the windows unit and the
user presses F1, a browser is opened to the MSDN.

Installation
Open externhelp.lpk in Lazarus and click the install button.

Configuration
In Lazarus IDE menu Tools / Options ... / Help / Extern


Author: Mattias Gaertner  mattias@freepascal.org

