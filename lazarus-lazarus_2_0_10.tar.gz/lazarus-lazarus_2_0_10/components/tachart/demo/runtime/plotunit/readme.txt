The demo "plotunit" show how to generate a series and insert it into a chart 
at runtime. The main series types of TAChart are supported.

The main plotting routines are in unit "uplot.pas":

- PrepareChart: Sets up chart title, footer and axis labels
- Plot: Takes a variety of parameters to plot the data array x vs y.