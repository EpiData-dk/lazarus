#!/bin/sh
../../../../../../tools/lazres ../lr_officeimport_img.res @lrimport_img.txt
