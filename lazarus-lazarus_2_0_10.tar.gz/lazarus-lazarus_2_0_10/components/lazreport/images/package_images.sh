#!/bin/sh
../../../tools/lazres ../source/lr_register.res @Package_images.txt
../../../tools/lazres ../source/bullets.res bitmaps/bulletgray.png bitmaps/bulletgreen.png designer/lrd_ins_fields.bmp
