This directory contains tests with marks for the ../finddeclarationtest.lpi.

Testing all these files:
./finddeclarationtest --suite=TestFindDeclaration_LazTests

Testing one file:
./finddeclarationtest --suite=TestFindDeclaration_LazTests --filemask=tchlp41.pp

Testing a bunch of files:
./finddeclarationtest --suite=TestFindDeclaration_LazTests --filemask=tchlp*.pp

