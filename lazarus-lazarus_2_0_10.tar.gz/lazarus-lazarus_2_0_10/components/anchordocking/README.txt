AnchorDocking implements a docking manager for LCL applications.
It handles drag and docking forms together via splitters and pages
(like a TPageControl).
It can save and restore layouts.

There is a runtime and a designtime package:

anchordocking.lpk
design/anchordockingdsgn.lpk

More information can be found at
http://wiki.lazarus.freepascal.org/Anchor_Docking

