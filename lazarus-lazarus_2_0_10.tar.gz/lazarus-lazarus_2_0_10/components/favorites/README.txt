IDE add-on for Favorites.
Adds favorite projects list into the drop-down menu of "Open" toolbar button.

Author: Ondrej Pokorny

Documentation: http://wiki.lazarus.freepascal.org/Favorites
