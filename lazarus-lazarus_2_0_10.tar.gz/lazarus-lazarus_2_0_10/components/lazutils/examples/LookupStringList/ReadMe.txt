﻿Demonstrate how TLookupStringList can quickly remove duplicates from a list without changing the order.

Author: Antônio Galvão
