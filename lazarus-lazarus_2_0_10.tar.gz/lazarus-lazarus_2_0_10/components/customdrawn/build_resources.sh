#! /bin/sh

../../tools/lazres customdrawnimages/android.lrs customdrawnimages/android_checkbox.bmp customdrawnimages/android_checkbox_checked.bmp