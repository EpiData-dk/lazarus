In fpc 2.6.2 the unit dbf was marked deprecated, due to the lack of a maintainer.
Now there is a maintainer again and the next fpc version has removed the deprecated warning.
