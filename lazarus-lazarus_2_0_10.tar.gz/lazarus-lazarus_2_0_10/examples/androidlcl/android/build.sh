#! /bin/sh

ant debug
~/Programas/android-sdk-linux/platform-tools/adb uninstall com.pascal.lcltest
~/Programas/android-sdk-linux/platform-tools/adb install bin/LCLExample-debug.apk
~/Programas/android-sdk-linux/platform-tools/adb logcat
