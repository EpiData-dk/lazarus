This example shows current state of Standard actions in LCL

- v1: only Edit actions are implemented
- v2: File action, dialog, action images

Example uses icons from this sets:

- Silk icon set 1.3 by Mark James (http://www.famfamfam.com/lab/icons/silk/)
- Tango Icon Library (http://tango.freedesktop.org/Tango_Icon_Library)
