This directory contains some patches, which may not have found their way into the LCL.

ToolButtonAutoSizeAlign.patch
=============================
1. makes toolbuttons preserve better their autosize width.
2. adds new toolbuttons *after* the existing ones.

Apply to improve the notebook behaviour and appearance.


FloatHostDockable.patch
=======================
Makes the default floating host form dockable.


NewClients.patch
----------------
Prevent loss of dock client management.
Apply to increase application stability and dock site appearance.