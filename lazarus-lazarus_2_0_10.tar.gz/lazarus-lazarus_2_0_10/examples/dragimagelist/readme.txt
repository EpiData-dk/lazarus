This example demonstrates the usage of DragImageList.

You will see Button image nearly cursor while drag. 
This Button image is from the DragImageList. You can
place any other image there to show it while drag 
operation.