Example for SynEdit's Bookmarks
(SynEdit is the editor used by the IDE)

This example shows how to display Bookmarks and other marks/icons in the gutter of the editor.

The gutter is the area on the left side of the editor, which also shows the line numbers.
It can display small icons, such as bookmarks or the breakpoint-symbols used by the IDE.

