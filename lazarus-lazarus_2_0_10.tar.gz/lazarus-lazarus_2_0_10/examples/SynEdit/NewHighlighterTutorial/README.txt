Example for the "Create your own SynEdit Highlighter" tutorial
(SynEdit is the editor used by the IDE)

The tutorial can be found at http://wiki.lazarus.freepascal.org/SynEdit_Highlighter

It explains the steps required to write your own highlighter from scratch.

