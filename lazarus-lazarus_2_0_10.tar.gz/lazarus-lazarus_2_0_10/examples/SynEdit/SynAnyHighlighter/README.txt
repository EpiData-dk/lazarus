Example for SynEdit's Highlighter: TSynAnySyn
(SynEdit is the editor used by the IDE)

TSynAnySyn allows one to highlight specific words in the text.
For example, it can be used to highlight every occurrence of 'Lazarus' in a specific color.

